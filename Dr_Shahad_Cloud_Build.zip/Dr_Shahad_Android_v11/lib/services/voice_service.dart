import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'app_config.dart';
import 'package:record/record.dart';

class VoiceService {
  const VoiceService();

  Future<VoiceResult> transcribeAndAnswer(Uint8List audioBytes, {String extension = 'm4a', String? language}) async {
    final baseUrl = await AppConfig.getBaseUrl();
    if (baseUrl.isEmpty) throw const VoiceException('لم يتم إعداد عنوان خادم Dr. Shahad.');
    final client = HttpClient();
    try {
      final request = await client.postUrl(Uri.parse('$baseUrl/v1/voice'));
      final boundary = '----DrShahadVoice${DateTime.now().microsecondsSinceEpoch}';
      request.headers.set(HttpHeaders.contentTypeHeader, 'multipart/form-data; boundary=$boundary');
      final out = BytesBuilder();
      final lang = language == null || language.isEmpty ? '' : '\r\n--$boundary\r\nContent-Disposition: form-data; name="language"\r\n\r\n$language';
      out.add(utf8Bytes('--$boundary\r\nContent-Disposition: form-data; name="file"; filename="voice.$extension"\r\nContent-Type: audio/mp4\r\n\r\n'));
      out.add(audioBytes);
      out.add(utf8Bytes('\r\n--$boundary$lang\r\n--$boundary--\r\n'));
      request.add(out.takeBytes());
      final response = await request.close();
      final body = await response.transform(utf8.decoder).join();
      if (response.statusCode < 200 || response.statusCode >= 300) throw VoiceException('تعذر معالجة الصوت (${response.statusCode}).', response.statusCode);
      final map = jsonDecode(body) as Map<String, dynamic>;
      final audioB64 = map['audioBase64'];
      return VoiceResult(text: (map['text'] ?? '').toString(), audioBytes: audioB64 is String ? Uint8List.fromList(base64Decode(audioB64)) : null);
    } on SocketException { throw const VoiceException('لا يوجد اتصال بالخادم.'); }
    finally { client.close(force: true); }
  }

  Uint8List utf8Bytes(String s) => Uint8List.fromList(utf8.encode(s));
}

class VoiceResult { final String text; final Uint8List? audioBytes; const VoiceResult({required this.text, this.audioBytes}); }
class VoiceException implements Exception { final String message; final int? statusCode; const VoiceException(this.message,[this.statusCode]); @override String toString()=>message; }
