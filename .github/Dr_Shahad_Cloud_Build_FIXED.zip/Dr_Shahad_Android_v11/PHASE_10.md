# Dr. Shahad — Phase 10

## Production deployment + remote web Admin

This phase prepares the backend for real HTTPS deployment and adds a browser-based Admin dashboard at `/admin`.

### Security
- OpenAI key stays only in the backend environment. Never put it in the APK. OpenAI explicitly recommends routing mobile requests through your own backend. 
- Admin password is stored only as SHA-256 hash in `.env`.
- `.env` is mode 600 and ignored by git.
- Caddy terminates HTTPS and renews certificates automatically.
- Login is rate-limited and admin sessions expire after 8 hours.
- API and file endpoints remain rate-limited.

### Deploy on an Ubuntu/Debian VPS
```bash
cd backend
sudo bash setup-production.sh
```
The script asks for your domain, OpenAI key, admin username, and admin password. It then launches Docker + Caddy.

### Remote control
Open:
`https://YOUR-DOMAIN/admin`

You can remotely enable/disable AI, images, PDF, voice, maintenance mode, change model/rate limits, and edit the system message.

### Android
After deployment, build the APK with the actual HTTPS URL:
```bash
flutter build apk --release --dart-define=AI_BASE_URL=https://YOUR-DOMAIN
```

The repository intentionally does not contain an OpenAI secret. Do not commit `.env`.
