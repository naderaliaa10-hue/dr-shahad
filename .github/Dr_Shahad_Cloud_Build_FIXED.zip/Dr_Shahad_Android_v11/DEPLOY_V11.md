# Dr. Shahad v11 — Remote Backend Deployment

This version is prepared for deployment without owning a VPS. The recommended path is Render because it supports Docker web services, public HTTPS, environment variables/secrets, and health checks.

Official deployment flow:
1. Create a GitHub repository.
2. Upload the contents of this folder.
3. Open Render and choose **New → Blueprint** (or create a Docker Web Service).
4. Render reads `render.yaml` and builds `backend/Dockerfile`.
5. Add `OPENAI_API_KEY`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD_HASH` as secrets.
6. Deploy and copy the generated `https://*.onrender.com` URL.
7. Put that URL into the Android build configuration.

The Android APK must never contain the OpenAI API key. Only the backend receives it.
