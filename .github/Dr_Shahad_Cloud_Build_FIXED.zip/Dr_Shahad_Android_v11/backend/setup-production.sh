#!/usr/bin/env bash
set -euo pipefail

# Dr. Shahad production setup for Ubuntu/Debian VPS.
# Run from backend/: sudo bash setup-production.sh

if [[ $EUID -ne 0 ]]; then echo 'Run as root: sudo bash setup-production.sh'; exit 1; fi

apt-get update
apt-get install -y ca-certificates curl openssl docker.io docker-compose-plugin
systemctl enable --now docker

read -r -p 'Your API domain (e.g. api.example.com): ' DOMAIN
read -r -s -p 'OpenAI API key: ' OPENAI_API_KEY; echo
read -r -p 'Admin username [ايمن القاضي 23]: ' ADMIN_USERNAME
ADMIN_USERNAME=${ADMIN_USERNAME:-ايمن القاضي 23}
read -r -s -p 'Admin password: ' ADMIN_PASSWORD; echo

HASH=$(printf '%s' "$ADMIN_PASSWORD" | sha256sum | awk '{print $1}')

cat > .env <<EOF
DOMAIN=$DOMAIN
OPENAI_API_KEY=$OPENAI_API_KEY
OPENAI_MODEL=gpt-5.6
OPENAI_TRANSCRIBE_MODEL=gpt-4o-mini-transcribe
OPENAI_TTS_MODEL=gpt-4o-mini-tts
OPENAI_TTS_VOICE=marin
ADMIN_USERNAME=$ADMIN_USERNAME
ADMIN_PASSWORD_SHA256=$HASH
EOF
chmod 600 .env
mkdir -p data
chmod 700 data

echo 'Starting Dr. Shahad backend...'
docker compose up -d --build

echo
echo 'Deployment complete.'
echo "Admin URL: https://$DOMAIN/admin"
echo "Health URL: https://$DOMAIN/health"
echo 'Android build:'
echo "flutter build apk --release --dart-define=AI_BASE_URL=https://$DOMAIN"
