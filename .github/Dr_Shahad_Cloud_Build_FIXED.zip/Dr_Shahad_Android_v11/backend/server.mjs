import express from 'express';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import OpenAI from 'openai';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({limit:'256kb'}));
app.use((req,res,next)=>{
  const id = crypto.randomUUID();
  req.requestId = id;
  res.setHeader('X-Request-Id', id);
  next();
});

const PORT = Number(process.env.PORT || 8080);
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6';
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

if (!process.env.OPENAI_API_KEY) {
  console.error('OPENAI_API_KEY is required.');
  process.exit(1);
}

// Admin credentials are server-side only. Never put the password in the APK.
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'ايمن القاضي 23';
const ADMIN_PASSWORD_SHA256 = process.env.ADMIN_PASSWORD_SHA256 || process.env.ADMIN_PASSWORD_HASH || '622c3987a3f4e4513bf847bd08dafc72797f3395e83773727dea8e7e15513827';
const adminSessions = new Map();
const SETTINGS_FILE = process.env.SETTINGS_FILE || path.join(process.cwd(), 'data', 'settings.json');
const defaultSettings = {
  aiEnabled: true,
  imageEnabled: true,
  pdfEnabled: true,
  voiceEnabled: true,
  maintenanceMode: false,
  model: MODEL,
  rateLimitPerMinute: 30,
  systemMessage: 'You are Dr. Shahad, a medical study assistant. Explain accurately at medical-student level. For medical images, describe visible findings and limitations and never present an image-only assessment as a definitive diagnosis. Encourage professional clinical evaluation when appropriate. Answer in the student\'s language.'
};
let settings = {...defaultSettings};
const pool = process.env.DATABASE_URL ? new pg.Pool({connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL.includes('localhost') ? false : {rejectUnauthorized:false}}) : null;
async function initSettings(){
  if(pool){
    await pool.query('CREATE TABLE IF NOT EXISTS app_settings (id integer PRIMARY KEY, data jsonb NOT NULL)');
    const r=await pool.query('SELECT data FROM app_settings WHERE id=1');
    if(r.rows[0]?.data) settings={...defaultSettings,...r.rows[0].data};
    else await pool.query('INSERT INTO app_settings(id,data) VALUES(1,$1)',[JSON.stringify(settings)]);
    return;
  }
  try { settings={...defaultSettings,...JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'))}; } catch {}
}
async function saveSettings() {
  if(pool) { await pool.query('UPDATE app_settings SET data=$1 WHERE id=1',[JSON.stringify(settings)]); return; }
  fs.mkdirSync(path.dirname(SETTINGS_FILE), {recursive:true});
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf8');
}

function sha256(value) { return crypto.createHash('sha256').update(value, 'utf8').digest('hex'); }
function safeEqualHex(a, b) {
  try { const aa = Buffer.from(a, 'hex'); const bb = Buffer.from(b, 'hex'); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); }
  catch { return false; }
}
function issueAdminToken() {
  const token = crypto.randomBytes(32).toString('base64url');
  adminSessions.set(token, Date.now() + 8 * 60 * 60 * 1000);
  return token;
}
function requireAdmin(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  const expires = adminSessions.get(token);
  if (!expires || expires < Date.now()) { adminSessions.delete(token); return res.status(401).json({error:'Admin authentication required'}); }
  next();
}

const limiter = rateLimit({ windowMs: 60_000, max: () => settings.rateLimitPerMinute, standardHeaders: true, legacyHeaders: false, message: {error:'تم تجاوز حد الطلبات مؤقتًا.'} });
const adminLoginLimiter = rateLimit({ windowMs: 15 * 60_000, max: 10, standardHeaders: true, legacyHeaders: false, message: {error:'محاولات تسجيل الدخول كثيرة. حاول لاحقًا.'} });
app.use('/v1/', limiter);
app.use('/admin/login', adminLoginLimiter);

const uploadAudio = multer({storage: multer.memoryStorage(), limits:{fileSize:10*1024*1024, files:1}, fileFilter:(_req,file,cb)=>cb(null,/^audio\//.test(file.mimetype))});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => cb(null, file.mimetype === 'application/pdf')
});

app.get('/health', (_req,res)=>res.json({ok:true, service:'dr-shahad-backend', maintenanceMode:settings.maintenanceMode}));
app.get('/v1/config', (_req,res)=>res.json({maintenanceMode:settings.maintenanceMode, aiEnabled:settings.aiEnabled, imageEnabled:settings.imageEnabled, pdfEnabled:settings.pdfEnabled, voiceEnabled:settings.voiceEnabled}));

const ADMIN_HTML = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dr. Shahad Admin</title><style>body{font-family:system-ui;background:#f3f7f7;margin:0;color:#16333a}.wrap{max-width:760px;margin:30px auto;padding:18px}.card{background:#fff;border-radius:18px;padding:20px;margin:14px 0;box-shadow:0 5px 22px #00000010}input,textarea{width:100%;box-sizing:border-box;padding:12px;margin:7px 0 12px;border:1px solid #ccd9dc;border-radius:10px}button{padding:11px 16px;border:0;border-radius:10px;background:#238b80;color:#fff;font-weight:700}.row{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid #edf1f2}.muted{color:#60777d}.hidden{display:none}.danger{background:#b42318}</style></head><body><div class="wrap"><h1>Dr. Shahad • Admin</h1><div id="login" class="card"><h2>تسجيل الدخول</h2><input id="u" placeholder="اسم المستخدم"><input id="p" type="password" placeholder="الرمز السري"><button onclick="login()">دخول</button><p id="le" class="muted"></p></div><div id="panel" class="hidden"><div class="card"><b>حالة الخادم:</b> <span id="status">...</span></div><div class="card" id="toggles"></div><div class="card"><label>Model</label><input id="model"><label>Rate limit / minute</label><input id="rate" type="number" min="1" max="120"><label>System message</label><textarea id="sys" rows="8"></textarea><button onclick="save()">حفظ الإعدادات</button> <button class="danger" onclick="logout()">خروج</button><p id="msg" class="muted"></p></div></div></div><script>let token='';const keys=[['aiEnabled','الذكاء الاصطناعي'],['imageEnabled','تحليل الصور'],['pdfEnabled','تحليل PDF'],['voiceEnabled','المساعد الصوتي'],['maintenanceMode','وضع الصيانة']];async function login(){const r=await fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u.value,password:p.value})});const d=await r.json();if(!r.ok){le.textContent=d.error||'فشل الدخول';return}token=d.token;loginBox(false);load()}function loginBox(on){document.getElementById('login').classList.toggle('hidden',!on);document.getElementById('panel').classList.toggle('hidden',on)}async function load(){const r=await fetch('/admin/settings',{headers:{Authorization:'Bearer '+token}});if(r.status===401)return logout();const d=await r.json();model.value=d.model||'';rate.value=d.rateLimitPerMinute||30;sys.value=d.systemMessage||'';toggles.innerHTML=keys.map(([k,l])=>'<div class="row"><span>'+l+'</span><input type="checkbox" data-k="'+k+'" '+(d[k]?'checked':'')+'></div>').join('');status.textContent='متصل ✓'}async function save(){const body={model:model.value,rateLimitPerMinute:Number(rate.value),systemMessage:sys.value};document.querySelectorAll('[data-k]').forEach(x=>body[x.dataset.k]=x.checked);const r=await fetch('/admin/settings',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(body)});const d=await r.json();msg.textContent=r.ok?'تم الحفظ ✓':(d.error||'فشل الحفظ')}async function logout(){try{await fetch('/admin/logout',{method:'POST',headers:{Authorization:'Bearer '+token}})}catch(_){}token='';loginBox(true)}loginBox(true)</script></body></html>`;
app.get('/admin', (_req,res)=>res.type('html').send(ADMIN_HTML));


app.post('/admin/login', (req,res)=>{
  const username = typeof req.body?.username === 'string' ? req.body.username : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const validUser = username === ADMIN_USERNAME;
  const validPass = safeEqualHex(sha256(password), ADMIN_PASSWORD_SHA256);
  if (!validUser || !validPass) return res.status(401).json({error:'بيانات الدخول غير صحيحة'});
  res.json({token:issueAdminToken(), expiresIn:28800});
});

app.get('/admin/settings', requireAdmin, (_req,res)=>res.json(settings));
app.get('/admin/status', requireAdmin, (_req,res)=>res.json({ok:true, maintenanceMode:settings.maintenanceMode, features:{ai:settings.aiEnabled,image:settings.imageEnabled,pdf:settings.pdfEnabled,voice:settings.voiceEnabled}, model:settings.model}));
app.patch('/admin/settings', requireAdmin, (req,res)=>{
  const allowed = ['aiEnabled','imageEnabled','pdfEnabled','voiceEnabled','maintenanceMode'];
  for (const key of allowed) if (typeof req.body?.[key] === 'boolean') settings[key] = req.body[key];
  if (typeof req.body?.model === 'string' && /^[a-zA-Z0-9._-]{1,80}$/.test(req.body.model)) settings.model = req.body.model;
  if (Number.isInteger(req.body?.rateLimitPerMinute)) settings.rateLimitPerMinute = Math.min(120, Math.max(1, req.body.rateLimitPerMinute));
  if (typeof req.body?.systemMessage === 'string' && req.body.systemMessage.length <= 4000) settings.systemMessage = req.body.systemMessage;
  saveSettings().then(()=>res.json(settings)).catch(()=>res.status(500).json({error:'تعذر حفظ الإعدادات'}));
});

app.post('/admin/logout', requireAdmin, (req,res)=>{
  const token = (req.headers.authorization || '').slice(7);
  adminSessions.delete(token);
  res.json({ok:true});
});

function guardFeature(feature, req, res, next) {
  if (settings.maintenanceMode && !req.path.startsWith('/admin')) return res.status(503).json({error:'التطبيق في وضع الصيانة مؤقتًا'});
  if (!settings[feature]) return res.status(403).json({error:'هذه الميزة متوقفة حاليًا من لوحة التحكم'});
  next();
}

app.post('/v1/chat', guardFeature.bind(null,'aiEnabled'), async (req,res,next)=>{
  try {
    const question = typeof req.body?.question === 'string' ? req.body.question.trim() : '';
    if (!question || question.length > 8000) return res.status(400).json({error:'Invalid question'});
    const response = await client.responses.create({ model: settings.model, input: [
      { role:'system', content:[{type:'input_text', text:settings.systemMessage}] },
      { role:'user', content:[{type:'input_text', text:question}] }
    ]});
    res.json({text:response.output_text || ''});
  } catch (e) { next(e); }
});

app.post('/v1/image', guardFeature.bind(null,'imageEnabled'), async (req,res,next)=>{
  try {
    const {mimeType, base64, prompt} = req.body || {};
    if (!['image/png','image/jpeg','image/webp'].includes(mimeType) || typeof base64 !== 'string' || base64.length > 12_000_000) return res.status(400).json({error:'Invalid image'});
    const response = await client.responses.create({ model:settings.model, input:[
      {role:'system',content:[{type:'input_text',text:settings.systemMessage}]},
      {role:'user',content:[
        {type:'input_text',text:typeof prompt==='string'&&prompt.trim()?prompt:'Analyze this medical image for study purposes.'},
        {type:'input_image',image_url:`data:${mimeType};base64,${base64}`}
      ]}
    ]});
    res.json({text:response.output_text || ''});
  } catch(e){ next(e); }
});

app.post('/v1/pdf', guardFeature.bind(null,'pdfEnabled'), upload.single('file'), async (req,res,next)=>{
  try {
    if (!req.file) return res.status(400).json({error:'PDF file is required'});
    const file = await client.files.create({ file: new File([req.file.buffer], req.file.originalname, {type:'application/pdf'}), purpose:'user_data' });
    try {
      const question = typeof req.body?.question === 'string' ? req.body.question : 'Explain and summarize this PDF for a medical student and extract high-yield questions.';
      const response = await client.responses.create({model:settings.model,input:[
        {role:'system',content:[{type:'input_text',text:settings.systemMessage+' Use the supplied PDF as the primary source.'}]},
        {role:'user',content:[{type:'input_text',text:question},{type:'input_file',file_id:file.id}]}
      ]});
      res.json({text:response.output_text || ''});
    } finally { try { await client.files.delete(file.id); } catch {} }
  } catch(e){ next(e); }
});

app.post('/v1/voice', guardFeature.bind(null,'voiceEnabled'), uploadAudio.single('file'), async (req,res,next)=>{
  try {
    if (!req.file) return res.status(400).json({error:'ملف الصوت مطلوب'});
    const transcript = await client.audio.transcriptions.create({
      file: new File([req.file.buffer], req.file.originalname || 'voice.m4a', {type:req.file.mimetype || 'audio/mp4'}),
      model: process.env.OPENAI_TRANSCRIBE_MODEL || 'gpt-4o-mini-transcribe',
      language: typeof req.body?.language === 'string' && req.body.language ? req.body.language : undefined
    });
    const question = transcript.text?.trim();
    if (!question) return res.status(422).json({error:'لم يتم التعرف على الكلام'});
    const response = await client.responses.create({model:settings.model,input:[
      {role:'system',content:[{type:'input_text',text:settings.systemMessage}]},
      {role:'user',content:[{type:'input_text',text:question}]}
    ]});
    const answer = response.output_text || '';
    const speech = await client.audio.speech.create({
      model: process.env.OPENAI_TTS_MODEL || 'gpt-4o-mini-tts',
      voice: process.env.OPENAI_TTS_VOICE || 'marin',
      input: answer.slice(0,4096),
      response_format:'mp3',
      instructions:'Speak clearly and warmly as a medical study assistant. Use a calm educational tone.'
    });
    const audio = Buffer.from(await speech.arrayBuffer()).toString('base64');
    res.json({text:answer, transcript:question, audioBase64:audio, audioMimeType:'audio/mpeg'});
  } catch(e){ next(e); }
});

app.use((err,req,res,_next)=>{ console.error(JSON.stringify({requestId:req.requestId,error:err?.message || String(err)})); res.status(500).json({error:'AI service request failed',requestId:req.requestId}); });
initSettings().then(()=>app.listen(PORT, ()=>console.log(`Dr Shahad backend listening on ${PORT}`))).catch(err=>{console.error(err);process.exit(1);});
