# Dr. Shahad — Render deployment

Render can deploy this Docker backend as a public HTTPS Web Service. It provides an `onrender.com` URL and terminates TLS for HTTPS.

## 1. Create the service
1. Create a GitHub repository and upload this project.
2. In Render: New → Web Service → connect the repository.
3. Select Docker runtime. If using the root `render.yaml`, use Blueprint deployment.
4. Confirm health check: `/health`.

## 2. Required secrets
Set these environment variables in Render:
- `OPENAI_API_KEY` — your OpenAI API key; never put it in the APK.
- `ADMIN_USERNAME` — your admin username.
- `ADMIN_PASSWORD_HASH` — bcrypt hash of your admin password.

Generate a bcrypt hash locally with Node:
`node -e "const bcrypt=require('bcryptjs'); console.log(bcrypt.hashSync(process.argv[1],12))" 'YOUR_PASSWORD'`

Do not commit `.env` or plaintext passwords.

## 3. App URL
After deployment Render provides an HTTPS URL such as:
`https://dr-shahad-backend.onrender.com`

Use that URL as the backend base URL when building the Android app.

## 4. Important
The free Render web service can spin down after inactivity, so the first request after idle time can be slower. For production usage, choose an appropriate paid instance and persistent storage/database as the project grows.


## v12 persistence
For persistent Admin settings across restarts/redeploys, set DATABASE_URL to a Render PostgreSQL connection string. Without DATABASE_URL, settings fall back to a local JSON file and may be lost when the service filesystem is replaced.
