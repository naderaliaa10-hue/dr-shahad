# Dr. Shahad Backend — Production

This backend keeps the OpenAI API key off the Android APK and provides remote Admin controls. OpenAI recommends routing mobile-app requests through your own backend and storing API keys in environment variables.

## Local
```bash
npm install
cp .env.example .env
# edit .env
npm start
```

## Production with HTTPS
1. Point your domain DNS A/AAAA record to the server.
2. Copy `.env.example` to `.env` and set all values.
3. Run `docker compose up -d --build`.
4. Caddy obtains and renews the TLS certificate automatically.

## Android
Build using:
```bash
flutter build apk --release --dart-define=AI_BASE_URL=https://YOUR-DOMAIN
```

The Admin panel controls AI, image, PDF, voice, maintenance mode, model, system prompt, and rate limits remotely.

Never commit `.env`, passwords, or API keys.
