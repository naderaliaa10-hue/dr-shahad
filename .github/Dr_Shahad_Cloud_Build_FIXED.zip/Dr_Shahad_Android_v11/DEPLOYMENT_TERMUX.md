# نشر Dr. Shahad من Termux

الأفضل تشغيل الـBackend على VPS/سيرفر عام، وليس على الهاتف، حتى يبقى متاحًا لصاحبك 24/7.

1. استأجر VPS يعمل Ubuntu/Debian.
2. انسخ مجلد `backend` إلى السيرفر.
3. نفّذ:
```bash
cd backend
sudo bash setup-production.sh
```
4. اربط DNS للنطاق الذي اخترته بعنوان السيرفر.
5. بعد نجاح النشر افتح:
```text
https://YOUR-DOMAIN/admin
```
6. ابنِ APK بعنوان الخادم:
```bash
flutter build apk --release --dart-define=AI_BASE_URL=https://YOUR-DOMAIN
```

لا تضع مفتاح OpenAI في Termux داخل مشروع Flutter أو APK.
