# Dr. Shahad v12 — Runtime Backend + Persistent Admin Settings

## What changed
- The Android app can now store the Backend HTTPS URL locally and change it without rebuilding the APK.
- The URL must be HTTPS and can be a Render `onrender.com` service URL.
- Admin login and AI/image/PDF/voice services use the saved Backend URL.
- Added `/v1/config` for remote feature state.
- Backend optionally persists Admin settings in PostgreSQL via `DATABASE_URL`.
- Fixed the Render environment variable name for the Admin password hash.
- Backend syntax checked successfully with Node.js.

## Important
The project is prepared, but it is **not actually deployed to Render yet** because deployment requires the user's Render account and its secrets. No OpenAI key is included in the APK or repository.

## After deployment
1. Copy the Render HTTPS URL.
2. Open Dr. Shahad → About → Server Settings.
3. Enter the HTTPS URL and save.
4. Test chat, image, PDF and voice.
5. Open Admin and verify remote controls.

For persistent Admin settings on Render, configure `DATABASE_URL` with a PostgreSQL connection string. Otherwise local JSON persistence may be lost when the service is replaced.
