# نشر Dr. Shahad v12

1. ارفع المشروع إلى GitHub.
2. في Render اختر New → Web Service ثم اربط مستودع GitHub.
3. استخدم Docker وملف `backend/Dockerfile` أو Blueprint `render.yaml`.
4. أضف الأسرار في Environment:
   - `OPENAI_API_KEY`
   - `ADMIN_USERNAME`
   - `ADMIN_PASSWORD_SHA256`
   - `DATABASE_URL` (موصى به للحفظ الدائم)
5. انتظر نجاح Deploy.
6. خذ رابط HTTPS الذي ينتهي بـ `onrender.com`.
7. داخل التطبيق: حول → إعداد الخادم → الصق الرابط → حفظ.
8. اختبر `/health` ثم تسجيل دخول Admin.

لا تضع مفتاح OpenAI داخل APK أو GitHub.
