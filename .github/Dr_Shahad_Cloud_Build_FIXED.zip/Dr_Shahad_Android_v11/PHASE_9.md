# PHASE 9 — Production Backend & Remote Control

- Added production Docker Compose deployment with Caddy HTTPS reverse proxy.
- Added health check and automatic container restart.
- Added request IDs for tracing.
- Added admin-login rate limiting (10 attempts / 15 minutes).
- Added remote admin status endpoint.
- Kept OpenAI key server-side only.
- Android remains configured to receive the backend URL through `--dart-define=AI_BASE_URL`.
- Admin settings remain remotely controllable after distributing the APK.

## Deploy
1. Copy `.env.example` to `.env` and set `DOMAIN`, `OPENAI_API_KEY`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD_SHA256`.
2. Run `docker compose up -d --build`.
3. Caddy obtains HTTPS automatically for the domain.
4. Build the APK with `flutter build apk --release --dart-define=AI_BASE_URL=https://YOUR-DOMAIN`.

Do not commit `.env` or any API key.
