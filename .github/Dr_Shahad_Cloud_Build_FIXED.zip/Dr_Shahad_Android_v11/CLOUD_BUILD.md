# Dr. Shahad - Cloud APK Build

This project includes a GitHub Actions workflow that builds a release APK automatically.

1. Upload this project to a GitHub repository.
2. Open Actions -> Build Dr Shahad APK.
3. Run workflow.
4. When complete, open the workflow run and download the `Dr-Shahad-APK` artifact.

No computer is required; GitHub can be used from the Android browser/app.
