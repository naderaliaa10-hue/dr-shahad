# PHASE 6 — Secure AI architecture + next feature foundation

- Removed the OpenAI secret from the Flutter client.
- Flutter now calls a backend over HTTPS.
- Backend keeps `OPENAI_API_KEY` in a server environment variable.
- Added rate limiting and upload size limits.
- PDF files are deleted from the OpenAI Files store after processing.
- Added backend health endpoint and production notes.
- Image, PDF and chat requests now flow through the backend.

Security note: production should add real user/device authentication, HTTPS-only access, abuse monitoring, and redacted logs before public release.
