import 'package:shared_preferences/shared_preferences.dart';

class AppConfig {
  static const _key = 'backend_url';
  static const compileTimeUrl = String.fromEnvironment('AI_BASE_URL', defaultValue: '');

  static Future<String> getBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_key)?.trim() ?? '';
    if (saved.isNotEmpty) return normalize(saved);
    if (compileTimeUrl.trim().isNotEmpty) return normalize(compileTimeUrl);
    return '';
  }

  static Future<void> setBaseUrl(String value) async {
    final url = normalize(value);
    final uri = Uri.tryParse(url);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      throw const FormatException('يجب إدخال رابط HTTPS صحيح للخادم.');
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, url);
  }

  static Future<void> clearBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  static String normalize(String value) => value.trim().replaceFirst(RegExp(r'/+$'), '');
}
