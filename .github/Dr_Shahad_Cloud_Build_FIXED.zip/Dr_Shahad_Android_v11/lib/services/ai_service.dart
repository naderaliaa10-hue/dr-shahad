import 'dart:convert';
import 'app_config.dart';
import 'dart:io';
import 'dart:typed_data';

class AiService {
  const AiService();

  Future<String> _baseUrl() async { final u = await AppConfig.getBaseUrl(); if (u.isEmpty) throw const AiConfigException('لم يتم إعداد عنوان خادم Dr. Shahad. افتح إعداد الخادم وأدخل رابط HTTPS.'); return u; }

  Future<String> ask(String question) async {
    final baseUrl = await _baseUrl();
    return _postJson(baseUrl, '/v1/chat', {'question': question});
  }

  Future<String> analyzeImage(Uint8List bytes, String mimeType, String prompt) async {
    final baseUrl = await _baseUrl();
    return _postJson(baseUrl, '/v1/image', {'mimeType': mimeType, 'base64': base64Encode(bytes), 'prompt': prompt});
  }

  Future<String> analyzePdf(Uint8List bytes, String fileName, String question) async {
    final baseUrl = await _baseUrl();
    final client = HttpClient();
    try {
      final request = await client.postUrl(Uri.parse('$baseUrl/v1/pdf'));
      final boundary = '----DrShahad${DateTime.now().microsecondsSinceEpoch}';
      request.headers.set(HttpHeaders.contentTypeHeader, 'multipart/form-data; boundary=$boundary');
      final out = BytesBuilder();
      final safeName = fileName.replaceAll('"', '_');
      out.add(utf8.encode('--$boundary\r\nContent-Disposition: form-data; name="question"\r\n\r\n${question.isEmpty ? 'Explain and summarize this PDF for a medical student and extract high-yield questions.' : question}\r\n'));
      out.add(utf8.encode('--$boundary\r\nContent-Disposition: form-data; name="file"; filename="$safeName"\r\nContent-Type: application/pdf\r\n\r\n'));
      out.add(bytes);
      out.add(utf8.encode('\r\n--$boundary--\r\n'));
      request.add(out.takeBytes());
      final response = await request.close();
      final body = await utf8.decoder.bind(response).join();
      if (response.statusCode < 200 || response.statusCode >= 300) throw AiRequestException('تعذر تحليل ملف PDF (${response.statusCode}).', response.statusCode);
      final data = jsonDecode(body);
      return data is Map && data['text'] is String ? data['text'] as String : '';
    } on SocketException { throw const AiRequestException('لا يوجد اتصال بالخادم.'); }
    finally { client.close(force: true); }
  }

  Future<String> _postJson(String baseUrl, String path, Map<String,dynamic> payload) async {
    final client = HttpClient();
    try {
      final request = await client.postUrl(Uri.parse('$baseUrl$path'));
      request.headers.contentType = ContentType.json;
      request.add(utf8.encode(jsonEncode(payload)));
      final response = await request.close();
      final body = await utf8.decoder.bind(response).join();
      if (response.statusCode < 200 || response.statusCode >= 300) throw AiRequestException('تعذر الاتصال بالخادم (${response.statusCode}).', response.statusCode);
      final data = jsonDecode(body);
      if (data is Map && data['text'] is String) return data['text'] as String;
      throw const AiRequestException('وصل رد غير صالح من الخادم.');
    } on SocketException { throw const AiRequestException('لا يوجد اتصال بالخادم.'); }
    on FormatException { throw const AiRequestException('استجابة الخادم غير صالحة.'); }
    finally { client.close(force: true); }
  }
}

class AiConfigException implements Exception { final String message; const AiConfigException(this.message); @override String toString()=>message; }
class AiRequestException implements Exception { final String message; final int? statusCode; const AiRequestException(this.message,[this.statusCode]); @override String toString()=>message; }
