import 'dart:convert';
import 'app_config.dart';
import 'dart:io';

class AdminService {
  const AdminService();

  Future<String> login(String username, String password) async {
    final data = await _request('/admin/login', method: 'POST', body: {'username': username, 'password': password});
    return data['token'] as String;
  }

  Future<Map<String, dynamic>> settings(String token) async => await _request('/admin/settings', token: token);

  Future<Map<String, dynamic>> update(String token, Map<String, dynamic> values) async => await _request('/admin/settings', method: 'PATCH', token: token, body: values);

  Future<void> logout(String token) async { await _request('/admin/logout', method: 'POST', token: token); }

  Future<Map<String, dynamic>> _request(String path, {String method = 'GET', String? token, Map<String, dynamic>? body}) async {
    final baseUrl = await AppConfig.getBaseUrl();
    if (baseUrl.isEmpty) throw const AdminException('لم يتم إعداد عنوان الخادم.');
    final client = HttpClient();
    try {
      final request = await client.openUrl(method, Uri.parse('$baseUrl$path'));
      request.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      if (token != null) request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      if (body != null) request.add(utf8.encode(jsonEncode(body)));
      final response = await request.close();
      final text = await utf8.decoder.bind(response).join();
      final data = jsonDecode(text);
      if (response.statusCode < 200 || response.statusCode >= 300) throw AdminException(data is Map && data['error'] is String ? data['error'] as String : 'فشل طلب لوحة التحكم.', response.statusCode);
      return Map<String, dynamic>.from(data as Map);
    } on SocketException { throw const AdminException('لا يوجد اتصال بالخادم.'); }
    finally { client.close(force: true); }
  }
}
class AdminException implements Exception { final String message; final int? statusCode; const AdminException(this.message, [this.statusCode]); @override String toString() => message; }
