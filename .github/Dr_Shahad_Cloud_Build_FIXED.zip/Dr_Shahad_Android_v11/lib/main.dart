import 'dart:typed_data';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'services/ai_service.dart';
import 'services/admin_service.dart';
import 'services/voice_service.dart';
import 'services/app_config.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const DrShahadApp());

class DrShahadApp extends StatelessWidget {
  const DrShahadApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner:false,title:'Dr. Shahad',theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF238B80)),scaffoldBackgroundColor:const Color(0xFFF5FAFB)),home:const Home());
}
class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home> {
  int tab=0; final chats=<String>['مرحبًا، أنا Dr. Shahad. كيف أستطيع مساعدتك في دراستك؟']; final controller=TextEditingController(); final ai=const AiService(); final voice=const VoiceService(); bool loading=false; bool recording=false; AudioRecorder? recorder; AudioPlayer? player;
  Future<void> send() async { final t=controller.text.trim(); if(t.isEmpty||loading)return; setState((){chats.add(t);controller.clear();loading=true;}); try{final answer=await ai.ask(t);if(mounted)setState(()=>chats.add(answer));}catch(e){if(mounted)setState(()=>chats.add('⚠️ $e'));}finally{if(mounted)setState(()=>loading=false);} }
  void openTools()=>setState(()=>tab=1);
  Future<void> toggleVoice() async {
    if (loading) return;
    if (recording) {
      final path = await recorder?.stop();
      setState(() => recording=false);
      if (path == null) return;
      setState(() => loading=true);
      try {
        final bytes = await File(path).readAsBytes();
        final r = await voice.transcribeAndAnswer(bytes);
        if (r.text.isNotEmpty) setState(() => chats.add(r.text));
        if (r.audioBytes != null) { player ??= AudioPlayer(); await player!.play(BytesSource(r.audioBytes!)); }
      } catch (e) { if (mounted) setState(() => chats.add('⚠️ $e')); }
      finally { if (mounted) setState(() => loading=false); }
      return;
    }
    recorder ??= AudioRecorder();
    if (!await recorder!.hasPermission()) { setState(() => chats.add('⚠️ نحتاج إذن الميكروفون لاستخدام المساعد الصوتي.')); return; }
    final path='${Directory.systemTemp.path}/dr_shahad_voice.m4a';
    await recorder!.start(const RecordConfig(encoder: AudioEncoder.aacLc), path:path);
    setState(() => recording=true);
  }
  @override void dispose(){recorder?.dispose();player?.dispose();controller.dispose();super.dispose();}
  @override Widget build(BuildContext context){final pages=[ChatScreen(messages:chats,controller:controller,onSend:send,loading:loading,onAttach:openTools,onVoice:toggleVoice,recording:recording),ToolsScreen(ai:ai),const LibraryScreen(),const AboutScreen()];return Scaffold(body:SafeArea(child:pages[tab]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[NavigationDestination(icon:Icon(Icons.chat_outlined),label:'المحادثة'),NavigationDestination(icon:Icon(Icons.medical_services_outlined),label:'الأدوات'),NavigationDestination(icon:Icon(Icons.menu_book_outlined),label:'المراجع'),NavigationDestination(icon:Icon(Icons.info_outline),label:'حول')]));}
}
class AppHeader extends StatelessWidget{const AppHeader({super.key});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(18,14,18,8),child:Row(children:[const Icon(Icons.medical_services,color:Color(0xFF238B80),size:30),const SizedBox(width:8),const Text('Dr. Shahad',style:TextStyle(fontSize:25,fontWeight:FontWeight.w800)),const Spacer(),IconButton(onPressed:(){ Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdminLoginScreen())); },icon:const Icon(Icons.admin_panel_settings_outlined))]));}
class ShahadAvatar extends StatefulWidget{const ShahadAvatar({super.key});@override State<ShahadAvatar> createState()=>_ShahadAvatarState();}
class _ShahadAvatarState extends State<ShahadAvatar> with SingleTickerProviderStateMixin{late AnimationController c;@override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:160));loop();}Future<void> loop()async{while(mounted){await Future.delayed(const Duration(seconds:4));if(!mounted)return;await c.forward();await c.reverse();}}@override void dispose(){c.dispose();super.dispose();}@override Widget build(BuildContext context)=>AnimatedBuilder(animation:c,builder:(_,__) {final sy=1-c.value*.9;return Container(width:158,height:158,decoration:BoxDecoration(shape:BoxShape.circle,gradient:const LinearGradient(colors:[Color(0xFFE8F7F5),Color(0xFFDDEFF2)]),border:Border.all(color:Colors.white,width:5),boxShadow:const[BoxShadow(blurRadius:24,color:Color(0x22000000),offset:Offset(0,10))]),child:Stack(alignment:Alignment.center,children:[Container(width:98,height:98,decoration:const BoxDecoration(shape:BoxShape.circle,color:Color(0xFFF4D1C1))),Positioned(top:50,left:45,child:Transform.scale(scaleY:sy,child:const _Eye())),Positioned(top:50,right:45,child:Transform.scale(scaleY:sy,child:const _Eye())),Positioned(top:78,child:Container(width:27,height:9,decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Color(0xFF985C63),width:2))))),Positioned(bottom:2,child:Container(width:74,height:39,decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(28))),child:const Icon(Icons.medical_services,color:Color(0xFF238B80),size:25))) ]));});}
class _Eye extends StatelessWidget{const _Eye();@override Widget build(BuildContext context)=>Container(width:14,height:14,decoration:const BoxDecoration(shape:BoxShape.circle,color:Color(0xFF30474F)));}
class ChatScreen extends StatelessWidget{final List<String> messages;final TextEditingController controller;final VoidCallback onSend;final VoidCallback onAttach;final bool loading; final VoidCallback onVoice; final bool recording; const ChatScreen({super.key,required this.messages,required this.controller,required this.onSend,required this.loading,required this.onAttach,required this.onVoice,required this.recording});@override Widget build(BuildContext context)=>Column(children:[const AppHeader(),Expanded(child:ListView(padding:const EdgeInsets.all(20),children:[const Center(child:ShahadAvatar()),const SizedBox(height:14),const Center(child:Text('مساعدك الطبي الدراسي',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold))),const Center(child:Text('Study • Understand • Remember',style:TextStyle(color:Colors.black54))),const SizedBox(height:20),...messages.asMap().entries.map((e)=>Container(alignment:e.key.isEven?AlignmentDirectional.centerStart:AlignmentDirectional.centerEnd,margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:e.key.isEven?Colors.white:const Color(0xFFE1F2EF),borderRadius:BorderRadius.circular(18)),child:Text(e.value,style:const TextStyle(fontSize:16,height:1.45))))])),if(loading)const Padding(padding:EdgeInsets.only(bottom:4),child:Text('Dr. Shahad تكتب…',style:TextStyle(color:Colors.black54))),Padding(padding:const EdgeInsets.all(12),child:Row(children:[IconButton.filledTonal(onPressed:onAttach,icon:const Icon(Icons.attach_file)),const SizedBox(width:6),Expanded(child:TextField(controller:controller,onSubmitted:(_)=>onSend(),decoration:const InputDecoration(hintText:'اكتب رسالتك…',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderSide:BorderSide.none,borderRadius:BorderRadius.all(Radius.circular(28)))))),const SizedBox(width:6),IconButton.filled(onPressed:loading?null:onSend,icon:const Icon(Icons.send)),IconButton.filledTonal(onPressed:loading?null:onVoice,icon:Icon(recording?Icons.stop_circle:Icons.mic))]))]);}
class ToolsScreen extends StatefulWidget{final AiService ai;const ToolsScreen({super.key,required this.ai});@override State<ToolsScreen> createState()=>_ToolsScreenState();}
class _ToolsScreenState extends State<ToolsScreen>{bool busy=false;String? result;
 Future<void> image()async{final r=await FilePicker.platform.pickFiles(type:FileType.image,withData:true);if(r==null||r.files.single.bytes==null)return;setState(()=>busy=true);try{final f=r.files.single;result=await widget.ai.analyzeImage(f.bytes!,_mime(f.extension),'حلل هذه الصورة الطبية بالتفصيل للطالب: ما الطبيعي؟ ما غير الطبيعي؟ وما أهم النقاط التعليمية؟');}catch(e){result='⚠️ $e';}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> pdf()async{final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['pdf'],withData:true);if(r==null||r.files.single.bytes==null)return;setState(()=>busy=true);try{final f=r.files.single;result=await widget.ai.analyzePdf(f.bytes!,f.name,'اقرأ هذا الـPDF وشرحه لي بطريقة طبية منظمة، ثم استخرج أهم النقاط والأسئلة المحتملة.');}catch(e){result='⚠️ $e';}finally{if(mounted)setState(()=>busy=false);}}
 String _mime(String? e){switch((e??'').toLowerCase()){case 'jpg':case 'jpeg':return'image/jpeg';case 'webp':return'image/webp';default:return'image/png';}}
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[const AppHeader(),const Text('أدوات الطالب الطبي',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:12),_t(Icons.psychology,'Study Mode','شرح وتبسيط ومراجعة',null),_t(Icons.quiz_outlined,'MCQ Generator','إنشاء أسئلة وإجابات',null),_t(Icons.local_hospital_outlined,'Clinical Cases','تدريب على الحالات السريرية',null),_t(Icons.image_search_outlined,'Image Tutor','اختر صورة X-ray / ECG / MRI لتحليلها',image),_t(Icons.picture_as_pdf_outlined,'PDF Tutor','اختر ملف PDF لقراءته وطرح الأسئلة عليه',pdf),_t(Icons.mic_none,'Voice Assistant','تحدث مع Dr. Shahad ثم استمع إلى الإجابة',null),_t(Icons.search,'Reference Search','البحث في المصادر الطبية المتاحة قانونيًا',null),if(busy)const Padding(padding:EdgeInsets.all(18),child:Center(child:CircularProgressIndicator())),if(result!=null)Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(16),child:Text(result!,style:const TextStyle(fontSize:15,height:1.5))))]);
 Widget _t(IconData i,String a,String b,VoidCallback? tap)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFE5F5F2),child:Icon(i,color:const Color(0xFF238B80))),title:Text(a,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(b),trailing:const Icon(Icons.chevron_right),onTap:tap));}

class AdminLoginScreen extends StatefulWidget{const AdminLoginScreen({super.key});@override State<AdminLoginScreen> createState()=>_AdminLoginScreenState();}
class _AdminLoginScreenState extends State<AdminLoginScreen>{
  final user=TextEditingController(); final pass=TextEditingController(); final admin=const AdminService(); bool busy=false; String? error;
  Future<void> login()async{if(busy)return;setState(()=>busy=true);try{final token=await admin.login(user.text.trim(),pass.text);if(!mounted)return;Navigator.of(context).pushReplacement(MaterialPageRoute(builder:(_)=>AdminPanel(token:token,service:admin)));}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
  @override void dispose(){user.dispose();pass.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('دخول لوحة التحكم')),body:ListView(padding:const EdgeInsets.all(22),children:[const SizedBox(height:35),const Icon(Icons.admin_panel_settings,color:Color(0xFF238B80),size:72),const SizedBox(height:20),const Text('Admin Control',textAlign:TextAlign.center,style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:25),TextField(controller:user,decoration:const InputDecoration(labelText:'اسم المستخدم',prefixIcon:Icon(Icons.person_outline),border:OutlineInputBorder())),const SizedBox(height:14),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'الرمز السري',prefixIcon:Icon(Icons.lock_outline),border:OutlineInputBorder()),onSubmitted:(_)=>login()),if(error!=null)Padding(padding:const EdgeInsets.only(top:14),child:Text('⚠️ $error',style:const TextStyle(color:Colors.red))),const SizedBox(height:22),FilledButton.icon(onPressed:busy?null:login,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.login),label:const Text('دخول آمن'))]));
}
class AdminPanel extends StatefulWidget{final String token;final AdminService service;const AdminPanel({super.key,required this.token,required this.service});@override State<AdminPanel> createState()=>_AdminPanelState();}
class _AdminPanelState extends State<AdminPanel>{Map<String,dynamic>? cfg;bool busy=true;String? error;
 @override void initState(){super.initState();load();}
 Future<void> load()async{try{final c=await widget.service.settings(widget.token);if(mounted)setState(()=>cfg=c);}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> setValue(String key,bool value)async{setState(()=>busy=true);try{final c=await widget.service.update(widget.token,{key:value});if(mounted)setState(()=>cfg=c);}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> logout()async{try{await widget.service.logout(widget.token);}catch(_){}if(mounted)Navigator.of(context).pop();}
  @override
  Widget build(BuildContext context) {
    if (error != null && cfg == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('لوحة التحكم')),
        body: Center(child: Text('⚠️ $error')),
      );
    }
    if (cfg == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dr. Shahad • Admin'),
        actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.security, color: Color(0xFF238B80)),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'لوحة التحكم محمية بجلسة خادم مؤقتة؛ لا يتم تخزين الرمز السري داخل التطبيق.',
                      style: TextStyle(height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _sw('الذكاء الاصطناعي', 'تشغيل/إيقاف المحادثة', 'aiEnabled'),
          _sw('تحليل الصور', 'X-ray / ECG / MRI', 'imageEnabled'),
          _sw('تحليل PDF', 'قراءة وشرح ملفات PDF', 'pdfEnabled'),
          _sw('المساعد الصوتي', 'تجهيز/إيقاف ميزة الصوت', 'voiceEnabled'),
          _sw('وضع الصيانة', 'إيقاف خدمات المستخدمين مؤقتًا', 'maintenanceMode'),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.memory),
              title: const Text('النموذج الحالي'),
              subtitle: Text('${cfg!['model'] ?? '-'}'),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.speed),
              title: const Text('حد الطلبات'),
              subtitle: Text('${cfg!['rateLimitPerMinute'] ?? '-'} طلب/دقيقة'),
            ),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.all(10),
              child: Text('⚠️ $error', style: const TextStyle(color: Colors.red)),
            ),
          if (busy) const LinearProgressIndicator(),
        ],
      ),
    );
  }
 Widget _sw(String title,String sub,String key){final value=cfg![key]==true;return Card(child:SwitchListTile(value:value,onChanged:(v)=>setValue(key,v),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(sub),secondary:const Icon(Icons.tune)));}
}

class LibraryScreen extends StatelessWidget{const LibraryScreen({super.key});@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[const AppHeader(),const Text('مكتبتي الطبية',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:14),const Card(child:ListTile(leading:Icon(Icons.picture_as_pdf),title:Text('PDF Tutor'),subtitle:Text('رفع ملف PDF وطلب شرح أو تلخيص أو أسئلة عليه')))]);}
class AboutScreen extends StatelessWidget{
  const AboutScreen({super.key});
  Future<void> server(BuildContext context) async {
    final controller=TextEditingController(text: await AppConfig.getBaseUrl());
    if(!context.mounted)return;
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('إعداد خادم Dr. Shahad'),content:TextField(controller:controller,keyboardType:TextInputType.url,decoration:const InputDecoration(labelText:'رابط Backend HTTPS',hintText:'https://your-service.onrender.com',border:OutlineInputBorder())),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:() async {try{await AppConfig.setBaseUrl(controller.text);if(context.mounted){Navigator.pop(context);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ عنوان الخادم ✓')));}}catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('⚠️ $e')));}},child:const Text('حفظ'))]));
    controller.dispose();
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[const AppHeader(),const SizedBox(height:20),const Center(child:ShahadAvatar()),const SizedBox(height:15),const Center(child:Text('Dr. Shahad',style:TextStyle(fontSize:27,fontWeight:FontWeight.w800))),const Center(child:Text('مساعد رقمي طبي للطلاب')),const SizedBox(height:25),const Card(child:ListTile(leading:Icon(Icons.language),title:Text('العربية / English'))),const Card(child:ListTile(leading:Icon(Icons.block),title:Text('بدون إعلانات'))),const Card(child:ListTile(leading:Icon(Icons.lock_outline),title:Text('الخصوصية والملفات'))),Card(child:ListTile(leading:const Icon(Icons.cloud_outlined),title:const Text('إعداد الخادم'),subtitle:const Text('تغيير رابط Backend دون إعادة بناء التطبيق'),trailing:const Icon(Icons.chevron_right),onTap:()=>server(context))),const SizedBox(height:30),const Center(child:Text('تم تعديله بواسطة أيمن القاضي',style:TextStyle(color:Colors.black45))) ]);
}
