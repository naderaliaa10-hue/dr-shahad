# Dr. Shahad — Phase 8

## Voice Assistant + Remote Settings Persistence

- Voice input is recorded on-device and uploaded only to the configured backend.
- Backend transcribes audio with OpenAI Speech-to-Text, sends the transcript to the configured medical assistant model, then generates MP3 speech.
- OpenAI API key remains server-side and is never embedded in the Android app.
- Admin can enable/disable voice remotely.
- Admin settings persist to `data/settings.json` across backend restarts.
- Audio upload is limited to 10 MB and accepted only for audio MIME types.
- TTS input is capped at 4096 characters.

## Build

Set the backend URL at build time:

`flutter build apk --release --dart-define=AI_BASE_URL=https://YOUR-BACKEND-DOMAIN`

## Backend environment

- `OPENAI_API_KEY`
- `OPENAI_MODEL`
- `OPENAI_TRANSCRIBE_MODEL` (default: `gpt-4o-mini-transcribe`)
- `OPENAI_TTS_MODEL` (default: `gpt-4o-mini-tts`)
- `OPENAI_TTS_VOICE` (default: `marin`)
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD_SHA256`
- `PORT`
- `SETTINGS_FILE`

Enable Voice Assistant from Admin after deployment.
