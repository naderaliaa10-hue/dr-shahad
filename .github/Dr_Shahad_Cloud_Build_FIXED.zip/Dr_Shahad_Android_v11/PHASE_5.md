# PHASE 5 — Image & PDF Tutor

Added:
- Image picker and medical-image analysis.
- PDF picker and upload to OpenAI Files API.
- PDF question/summary workflow through Responses API.
- Loading/error states in the UI.
- file_picker dependency.

Important: the API key is still passed at build/run time with --dart-define. For a production release, move API access behind a secure backend so the secret is not embedded in the APK.
