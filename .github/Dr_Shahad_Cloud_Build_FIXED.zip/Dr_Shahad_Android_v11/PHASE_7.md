# Phase 7 — Secure Admin Control

Added a server-side Admin Control panel.

Security design:
- Admin password is never stored in the Android app.
- Backend stores only a SHA-256 password hash.
- Admin login issues an expiring in-memory bearer token (8 hours).
- Admin API is protected by Authorization: Bearer.
- Admin can toggle AI, image analysis, PDF analysis, voice readiness, and maintenance mode.
- Admin can inspect the current model and rate-limit configuration.

Configured administrator username: `ايمن القاضي 23`
The password is configured server-side as a SHA-256 hash and is intentionally not embedded in the APK.

For production, deploy the backend behind HTTPS and use a managed secret store/environment variables. A database/Redis-backed session store should replace the in-memory sessions if running multiple backend instances.
